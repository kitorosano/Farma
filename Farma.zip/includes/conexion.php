<?php
$linkConnect = 'mysql:host=localhost;dbname=id14714542_farma';
$userConnect = 'id14714542_root';
$passConnect = "Kito123321**";

try {
  $pdo = new PDO($linkConnect, $userConnect, $passConnect);
  // print_r("Conectado a la base de datos! <br><br><br>");


} catch (PDOException $e) {
  print "¡Error al conectarse a la base de datos!: <br>" . $e->getMessage() . "<br/>";
  die();
}
